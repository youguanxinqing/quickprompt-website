# Quick Prompt — AI 技能

让你的 AI agent（Claude Code 等）直接帮你**查、建、改** Quick Prompt 里的提示词。

## 前置

- 已安装 macOS 版 **Quick Prompt**（[官网下载](https://quickprompt.youguanxinqing.com)）。
- 一个支持 skill 的 agent（如 Claude Code）。

## 安装

把 `quickprompt/` 整个文件夹放进你的 skills 目录：

```bash
mkdir -p ~/.claude/skills
cp -R quickprompt ~/.claude/skills/
```

重开 agent 即可。之后直接说人话就行：

- 「我有没有关于代码注释的 prompt？」 → AI 读库回答
- 「把刚才这段写成一个 prompt 存进 Quick Prompt」 → AI 新建（会在 App 里打开待你过目）
- 「改一下那条『太多注释』，加一个 {{语言}} 变量」 → AI 按 id 更新

## 它怎么工作

- **读**：直接读你本地的 `library.json`（只读）。
- **建 / 改**：通过 `quickprompt://` URL scheme 触发 App，App 会**打开编辑器让你过目后保存**——
  不会静默落库。
- 全程本地，无网络、无密钥；不会删除（删除请在 App 内做）。

详见 `quickprompt/SKILL.md`。
