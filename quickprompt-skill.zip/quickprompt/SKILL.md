---
name: quickprompt
description: Read, create, and update prompts in the user's Quick Prompt app (macOS). Use when the user wants to save/add a prompt to Quick Prompt, asks whether they already have a prompt about something, wants to find/list their prompts, or wants to edit an existing one. Triggers on phrases like "存进 Quick Prompt", "加一个 prompt", "我有没有关于 X 的 prompt", "改一下那条 prompt", "save this to Quick Prompt", "add a prompt", "do I have a prompt for…", "update that prompt".
---

# Quick Prompt

Quick Prompt is a macOS app that stores the user's reusable prompts. This skill lets you
**read** their library, **create** new prompts, and **update** existing ones — all locally,
no network, no keys.

- **Read** = read the library JSON file directly (read-only, never write it).
- **Create / Update** = trigger the app via its `quickprompt://` URL scheme. The app applies
  the change, then **opens its editor on the prompt for the user to review** — it is *pending
  review*, not silently published. Always tell the user to glance at it and save.

## 1. Where the data lives

The library is a plain JSON file. Try these paths in order (first that exists wins):

```
~/Library/Group Containers/group.com.guan.quickprompt/Library/library.json
~/Library/Application Support/QuickPrompt/library.json
```

Top-level keys: `prompts`, `tagDefinitions`, `folders`, `events`, `schemaVersion`.

A prompt object:

```json
{
  "id": "B529A9F9-0381-45BB-8506-17DBB3B8B6FA",
  "title": "太多注释",
  "body": "…the prompt text, may contain {{变量}} placeholders…",
  "tags": ["代码"],
  "isFavorite": false,
  "usageCount": 17,
  "createdAt": "2026-06-10T23:21:00Z",
  "updatedAt": "2026-06-11T14:31:56Z",
  "lastUsedAt": "2026-06-16T05:18:36Z",
  "sortIndex": 0,
  "variables": []
}
```

Notes:
- `{{name}}` in `body` are fill-in variables. The app auto-detects them from the body —
  you do **not** need to populate the `variables` array when creating.
- `id` is an uppercased UUID. You need it to update a prompt.

## 2. Read (find / list / check duplicates)

Just read the file. Examples:

```bash
LIB="$HOME/Library/Group Containers/group.com.guan.quickprompt/Library/library.json"
[ -f "$LIB" ] || LIB="$HOME/Library/Application Support/QuickPrompt/library.json"

# list titles + ids
jq -r '.prompts[] | "\(.id)\t\(.title)"' "$LIB"

# find prompts mentioning a keyword (title or body)
jq -r --arg k "注释" '.prompts[] | select(.title+.body | contains($k)) | "\(.id)\t\(.title)"' "$LIB"

# existing tags (reuse these instead of inventing new ones)
jq -r '[.prompts[].tags[]] | unique[]' "$LIB"
```

Before creating, **read first** to avoid duplicates and to reuse existing tags.

## 3. Create

Trigger with parameters. All values must be percent-encoded; the robust way (handles
multi-line bodies, quotes, CJK) is to let Python build the URL and call `open`:

```bash
python3 - <<'PY'
import urllib.parse, subprocess
title = "代码注释精简器"
body  = """精简下面这段代码的注释：只保留必要的、解释「为什么」的注释，
删掉复述代码的废话。语言保持 {{语言}}，只输出修改后的代码。"""
tags  = "代码"          # comma-separated; reuse existing tags; max 3
q = urllib.parse.urlencode({"title": title, "body": body, "tags": tags})
subprocess.run(["open", f"quickprompt://create?{q}"])
PY
```

For a trivial one-liner with no special characters you can also do it inline (quote the
whole URL so the shell doesn't split it):

```bash
open "quickprompt://create?title=Quick%20note&body=Hello%20%7B%7Bname%7D%7D"
```

Parameters: `title` (optional, defaults to "未命名提示词"), `body` (optional),
`tags` (optional, comma-separated, max 3). No params → opens a blank new prompt.

After triggering, tell the user: *"已在 Quick Prompt 打开编辑器，过目后保存。"*

Free tier is capped at 10 prompts. If the user is over the cap and not on Pro, create
won't land — the app shows an upgrade screen instead. If a created prompt doesn't appear,
tell them they may have hit the free limit.

## 4. Update

Get the target `id` from the library (§2), then send only the fields you want to change —
omitted fields keep their current value:

```bash
python3 - <<'PY'
import urllib.parse, subprocess
pid  = "B529A9F9-0381-45BB-8506-17DBB3B8B6FA"   # from library.json
body = """新的正文……"""
q = urllib.parse.urlencode({"id": pid, "body": body})
subprocess.run(["open", f"quickprompt://update?{q}"])
PY
```

Parameters: `id` (**required**), plus any of `title` / `body` / `tags` to overwrite.
Passing `tags=` (empty) clears tags; omitting `tags` leaves them untouched.
An unknown `id` is ignored (nothing is created).

## 5. Boundaries

- **Never write `library.json` directly** — the running app holds it in memory and would
  overwrite you, and direct writes don't trigger iCloud sync. Writes go through `quickprompt://`.
- **No delete** — deletion is destructive; the user does it inside the app.
- **macOS only** — this skill drives the Mac app via shell + URL scheme.
- Quick Prompt must be installed and running (or able to launch) for create/update to land.
